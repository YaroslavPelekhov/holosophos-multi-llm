from pathlib import Path

DIR_PATH = Path(__file__).parent
ROOT_PATH = DIR_PATH.parent
PROMPTS_DIR_PATH = DIR_PATH / "prompts"
